import 'package:flutter/material.dart';

class PaginaPremio extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('¡Felicidades!'),
      ),
      body: Center(
        child: Text(
          'Has ganado un premio',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
