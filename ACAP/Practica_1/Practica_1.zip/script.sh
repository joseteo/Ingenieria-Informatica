#!/bin/bash

srun -Aacap -p acap ./pi_ej1 2147483647
