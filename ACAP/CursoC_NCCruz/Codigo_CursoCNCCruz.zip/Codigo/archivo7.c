#include <stdio.h>

#define NUMERO 5 //Se suele poner
                 //en mayusculas

int main(void){
	printf("Número: %d\n", NUMERO);
	return 0;
}
