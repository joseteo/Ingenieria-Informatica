#include <stdio.h>

int main(){
	printf("240 & 170 = %d\n", 240 & 170);
	printf("8 | 64 = %d\n", 8 | 64);
	printf("36 ^ 255 = %d\n", 36 ^ 255);
	printf("~7 = %d\n", ~7);
	printf("3 << 2 = %d\n", 3 << 2);
	printf("16 >> 2 = %d\n", 16 >> 2);
	return 0;
}
