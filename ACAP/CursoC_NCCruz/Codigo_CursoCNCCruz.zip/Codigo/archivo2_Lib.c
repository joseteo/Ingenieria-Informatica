#include "archivo2_Lib.h"

void Saludar(void){
	printf("¡Hola Mundo!\n");
}
