#include <stdio.h>

int main(void){								//int main(int argc, char* argv[]){//Declaracion alternativa para recibir parametros
	printf("¡Hola Mundo!\n");
	return 0;
}
