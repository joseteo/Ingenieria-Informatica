#include <stdio.h>

static int valorGlobal = 9;

void Saludar(void){
	printf("¡Hola Mundo!\n");
	printf("Y mi Valor Global es: %d\n", valorGlobal);
}
