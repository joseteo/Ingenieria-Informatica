int valorGlobal = 0;

int main(){
	int valor;
	valor = 6;
	int otroValor = 12;
	//const int yOtro;// Esto
	//yOtro = 24;	  // NO
	const int yOtro = 24;
	return 0;
}
