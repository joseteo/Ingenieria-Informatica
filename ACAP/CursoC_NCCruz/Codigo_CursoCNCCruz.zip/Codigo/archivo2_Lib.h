#include <stdio.h>

void Saludar(void);
