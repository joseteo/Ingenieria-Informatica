#include "archivo2_Lib.h"

int main(void){
	Saludar();
	printf("Esto es un cambio\n");
	return 0;
}
