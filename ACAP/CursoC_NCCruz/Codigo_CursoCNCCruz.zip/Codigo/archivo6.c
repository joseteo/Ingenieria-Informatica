#include <stdio.h>

int main(void){
	int valor = 6;
	//int valor = 8;
	float valor = 3.14;
	return 0;
}
